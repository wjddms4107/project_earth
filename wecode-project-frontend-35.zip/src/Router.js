import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Main from './pages/Main/Main.tsx';
import SubMain from './pages/SubMain/SubMain';

const Router = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/main" element={<Main />} />
        <Route path="/submain" element={<SubMain />} />
      </Routes>
    </BrowserRouter>
  );
};

export default Router;
