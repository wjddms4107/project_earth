import { data } from 'autoprefixer';
import Streamedian from '../Streamedian';

const { observable, runInAction } = require('mobx');
const { observer } = require('mobx-react');
const { useState } = require('react');

const Main = () => {
  const state = observable({
    compA: 'a',
    compB: 12,
    compC: null,
  });

  const onClickB = () => {
    runInAction(() => {
      state.compB++;
    });
  };

  const onClickAlpha = () => {};

  return (
    <div className="w-screen h-screen flex justify-center items-center flex-col">
      <div />
      <div className="max-w-2xl max-h-fit">
        <Streamedian id="test" url="rtsp://192.168.0.102/stream1" />
      </div>
      <p className="text-3xl font-bold underline">Hello world!</p>
      <p className="border-solid border-2 border-black">123</p>
      <button
        className="py-2 px-4 rounded-lg shadow-md text-white bg-blue-500"
        onClick={() => onClickB()}
      >
        compB Increaser
      </button>
      <button
        className="py-2 px-4 rounded-lg shadow-md text-white bg-blue-500"
        onClick={() => onClickAlpha()}
      >
        alpha
      </button>
      <p>state.compA = {state.compA}</p>
      <p>state.compB = {state.compB}</p>
    </div>
  );
};

export default Main;
