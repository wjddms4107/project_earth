import Streamedian from '../Streamedian';

const SubMain = () => {
  return (
    <>
      <nav className="nav bg-slate-700 w-full h-10 px-8">
        <span className="logo text-xl text-white leading-10">MUSMA</span>
      </nav>
      <main className="flex justify-center items-start box-border w-screen h-screen mt-10">
        <section className="flex justify-center items-start flex-wrap max-w-7xl ">
          <div className="leftPanel w-7/12 h-96 border-solid border-2 border-black">
            <div className="dataChart" />
          </div>
          <div className="rightPanel w-5/12 h-fit flex justify-center items-start flex-col">
            <div className="videoOut">
              <div className="max-w-full max-h-fit">
                <Streamedian id="test" url="rtsp://192.168.0.102/stream1" />
              </div>
            </div>
            <div className="odList">
              <div className="helper" />
              <div className="label-container">
                <h2>Detected Objects</h2>
                <p>설명</p>
              </div>
            </div>
          </div>
        </section>
      </main>
    </>
  );
};

export default SubMain;
